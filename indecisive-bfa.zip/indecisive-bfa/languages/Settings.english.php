<?php
// Version: 2.0; Settings

// Important! Before editing these language files please read the text at the top of index.english.php.

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/indearrow.png';
$txt['theme_description'] = 'Indecisive 2016 Theme';

?>
